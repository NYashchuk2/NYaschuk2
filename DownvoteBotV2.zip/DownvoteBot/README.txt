DownvoteBot V2

Setup-
	*Inside the files find logininfo.txt
	*first line is the inside loop delay-
		*if you have a very fast computer and internet set it to 1-2 seconds
		*otherwise i recomend 3-5 seconds
		*NO decimals, also 0 is NOT recomended
	*second line is outer loop delay-
		*it is the delay after cycling thru all of your accounts 
		*any whole number value is okay 
		*300 to 600 seconds is my personal recomendation
	*third line is the number of posts to be downvoted
		*don't recomend too many (1-6 is fine)
	*next lines are accounts and passwords-
		*it should go in order of account and password on the next line(like the sample accounts)
		*remove the sample accounts(they don't work)
		*on reddit, number of accounts is practically infinite for each email you just can't spam them(takes ~5 mins between creation of accounts)
		*do NOT use your main accont(s) (threat of a ban)
		*it is recomended after creating an alt account you should go to reddit settings and disable custom community themes
	*if the number of lines is even - you did something wrong

Run-
	*after setting everything up just click the DownvoteBot exe file
		*creating a shortcut is highly recomended
	*you can minimize the google and command window
	*clicking on stuff will most likely crash it(if it opens something)
	*for now it downvotes by first upvoting then deleting the upvote button then downvoting (don't ask why)
	*if it crashes, please tell me what happened (also copy-pasting what the comand prompt says is nice too)
	*it will crash eventually, most likely due to reddit popups
	*if you want to close it you should close the command prompt that pops up upon activation
	*after completing the outer loop it will just google "loop complete" and after the outer loop delay will comeback to downvoting
